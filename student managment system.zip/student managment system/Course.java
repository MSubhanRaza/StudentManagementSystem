public class Course {
    private int courseId;
    private String courseName;
    private String courseYear;
    private String courseType;
    private String courseDescription;
    private String courseStudentId;


    public static void addCourse(){

    }
    public static void editCourse(){

    }
    public static void deleteCourse(){

    }
    public static void searchCourse(){

    }


}
