public class Teacher {
    private String teacherName;
    private int teacherId;
    private int teacherCollageId;
    private String teacherCellNum;
    private String userName;
    private String password;
}
