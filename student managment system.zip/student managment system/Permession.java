import java.io.*;
public class Permession {
    private int permissionId;
    private int permissionRoleId;
    private String permissionTitle;
    private String permessionModule;
    private String permissionDescription;



    public static void addPermission(){

    }
    public static void editPermission(){

    }
    public static void deletePermission(){

    }
    public static void serchPermission(){}
}
