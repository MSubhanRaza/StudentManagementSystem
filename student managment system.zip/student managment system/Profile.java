public class Profile {
    private String profileName;
    private int profileId;
    private String profileDescription;
    private String profileType;


}
