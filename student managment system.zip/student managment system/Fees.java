public class Fees {
    private int feesId;
    private String type;
    private String amoount;
    private String description;
    private int courseId;
    private String total;


    public static void addFees(){}
    public static void editFees(){}
    public static void deleteFees(){}
    public static void searchFees(){}
}
