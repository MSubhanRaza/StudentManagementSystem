import java.util.Date;
public class Exam {
    private int examId;
    private String examName;
    private String examDescription;
    private String examType;
    private Date examDate;
    private int examStudentId;


}
