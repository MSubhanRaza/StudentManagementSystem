public class Student {
   private String studentName;
    private int studentId;
    private int studentCollageId;
    private String studentCellNum;
    private String userName;
    private String password;


    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public void setStudentCollageId(int studentCollageId) {
        this.studentCollageId = studentCollageId;
    }

    public void setStudentCellNum(String studentCellNum) {
        this.studentCellNum = studentCellNum;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getStudentCollageId() {
        return studentCollageId;
    }

    public String getStudentCellNum() {
        return studentCellNum;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public static void addStudent(){

    }
    public static void deleteStudent(){

    }
    public static void editStudent(){

    }
    public static void serchStudent(){

    }
}
