public class Role {
    
}
