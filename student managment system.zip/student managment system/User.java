public interface User {



}
